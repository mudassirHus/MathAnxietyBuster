/* ◄◉══▰▰▰  SAFE JS CONSTRUCTS  ▰▰▰══◉► */
const safeConstructRules = {
    'eqeqeq': ['error', 'always'],           // ✅ use === !==              ❌ == !=
    'no-implicit-coercion': 'error',         // ✅ Boolean(x)               ❌ !!x, +x
    'no-extend-native': 'error',             // ✅ utils.map()              ❌ Array.prototype.x = fn
    'no-proto': 'error',                     // ✅ Object.getPrototypeOf(x) ❌ x.__proto__
    'no-caller': 'error',                    // ✅ normal calls             ❌ arguments.callee()
    'no-labels': 'error',                    // ✅ structured loops         ❌ label: for(...)
    'no-iterator': 'error',                  // ✅ for...of                 ❌ obj.__iterator__()
    'no-invalid-this': 'error',              // ✅ valid this usage         ❌ this in arrow/global scope
    'no-param-reassign': 'error',            // ✅ return new value         ❌ mutate parameters
    'prefer-const': 'error',                 // ✅ const a = 1              ❌ let a = 1 (never reassigned)
    'no-fallthrough': 'error',               // ✅ explicit break           ❌ accidental fallthrough
    'consistent-return': 'error',            // ✅ consistent returns       ❌ mixed return paths
    'no-unreachable': 'error',               // ✅ remove dead code         ❌ code after return/throw
    'no-unused-expressions': 'error',        // ✅ meaningful statements    ❌ unused expressions
    'no-shadow': 'error',                    // ✅ distinct variable names  ❌ shadowed variables
    'no-const-assign': 'error',              // ✅ do not reassign const values
    'no-throw-literal': 'error',             // ✅ throw Error objects      ❌ throw strings/values
    'no-nested-ternary': 'error',            // ✅ readable logic           ❌ nested ternaries
    'no-useless-concat': 'error',            // ✅ clear strings            ❌ redundant concatenation
    'require-await': 'error',                // ✅ async does async work    ❌ async without await
    'no-unsafe-finally': 'error',            // ✅ proper control flow in finally
    'no-global-assign': 'error',             // ✅ do not overwrite built-in globals
    'no-eval': 'error',                      // ✅ a + b             ❌ eval("a + b")
    'no-implied-eval': 'error',              // ✅ setTimeout(fn, 1000)    ❌ setTimeout("x=1", 1000)
    'prefer-arrow-callback': 'error',        // Prefer arrow functions for callbacks (when safe)
    'arrow-body-style': ['error', 'as-needed'],  // Prefer concise arrow bodies when possible
    'no-else-return': ['error', {
        allowElseIf: false                   // ✅ early return             ❌ unnecessary else
    }],
};

export default safeConstructRules;
