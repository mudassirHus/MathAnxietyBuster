/* ◄◉══▰▰▰  STRICT TYPESCRIPT SAFETY  ▰▰▰══◉► */
const typeScriptRules = {
  '@typescript-eslint/no-explicit-any': 'error',         // ✅ typed values       ❌ let x: any
  '@typescript-eslint/no-unsafe-assignment': 'error',    // ✅ safe typed assign  ❌ const x = y as any
  '@typescript-eslint/no-unsafe-call': 'error',          // ✅ typed fn calls     ❌ (x as any)()
  '@typescript-eslint/no-unsafe-member-access': 'error', // ✅ obj.prop (typed)   ❌ (x as any).prop
  '@typescript-eslint/no-unsafe-return': 'error',        // ✅ typed returns      ❌ return (x as any)

  '@typescript-eslint/prefer-readonly': 'error',         // ✅ readonly props     ❌ mutable by default
  '@typescript-eslint/prefer-function-type': 'error',    // ✅ type Fn = (a)=>b   ❌ interface Fn { (a): b }
  '@typescript-eslint/no-empty-interface': 'error',      // ✅ meaningful types   ❌ interface A {}
  '@typescript-eslint/no-unused-vars': ['error'],        // ✅ no unused vars/params ❌ unused

  '@typescript-eslint/strict-boolean-expressions': 'error', // ✅ if (isReady)      ❌ if (arr) / if (obj)
  '@typescript-eslint/no-floating-promises': 'error',       // ✅ await fn() / save promise ❌ fn() (use void fn() if fire-and-forget)
  '@typescript-eslint/no-misused-promises': 'error',        // ✅ void handler()    ❌ setTimeout(async () => {...})
  '@typescript-eslint/ban-ts-comment': 'error',             // ✅ fix types         ❌ // @ts-ignore
  '@typescript-eslint/no-non-null-assertion': 'error',      // ✅ safe checks       ❌ foo!.bar
  '@typescript-eslint/no-inferrable-types': 'error',        // ✅ let x = 1         ❌ let x: number = 1
  '@typescript-eslint/switch-exhaustiveness-check': 'error',  // ✅ all cases handled ❌ missing case in switch
  '@typescript-eslint/await-thenable': 'error',                // ✅ await Promise      ❌ await non-Promise
  '@typescript-eslint/no-for-in-array': 'error',                  // ✅ for-of over array  ❌ for-in over array
  '@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }], // ✅ type imports      ❌ value imports for types 
};

export { typeScriptRules };