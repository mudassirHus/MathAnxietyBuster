## `indent: ['error', 'tab']`
- Spaces vs Tabs war exists — we pick **tabs**
- Tabs represent **indentation**; spaces represent **alignment**
- Mixing tabs and spaces causes noisy diffs across GitHub, GitLab, Bitbucket, and IDE diff tools — so we stick to tabs

## `quotes: ['error', 'single']`
- Use **single quotes** for strings
- Consistency over preference
- Avoid mixing single and double quotes in the same codebase
```js
const msg = 'hello'; // ✅
const msg = "hello"; // ❌
```

## `semi: ['error', 'always']`
- As crazy as it sounds, JavaScript allows statements **without semicolons**
- This can cause weird bugs!
```js
const numbers = [1, 2, 3] // ❌ No semiclon
[1, 2, 3].forEach(n => console.log(n));
//What JS sees (💥 TypeError)
const numbers = [1, 2, 3][1, 2, 3].forEach(n => console.log(n)); 

const numbers = [1, 2, 3]; // ✅ Correct (Always use semicolon)
[1, 2, 3].forEach(n => console.log(n));
```

## `max-len`
### `ignoreStrings: true`
Allows long string literals (errors, logs, messages) without forced wrapping.
When error strings are wrapped or split across lines, they become harder to search for in the codebase.
```js
throw new Error('very long string'); // ✅ Correct
throw new Error( // ❌ forced multiline template literal
  `very 
  long
  string`
);
throw new Error( // ❌ forced wrap using concatenation
  'very' +
  'long' +
  'string'
);
```
### `ignoreTemplateLiterals: true`
Allows long template literals (strings with interpolation).
```js
// ✅ Correct
const message = `User ${userId} attempted to access ${resource}`;
```
### `ignoreRegExpLiterals: true`
Allows long regular expressions without breaking readability.
```js
// ✅ Correct
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}$/;
```

## `linebreak-style: ['error', 'unix']`

- Enforce **Unix-style line endings** (`\n`)
- Prevent `LF` vs `CRLF` diff noise across operating systems
- Keeps files consistent across Linux, macOS, and CI

```txt
line one\n
line two\n     // ✅ Unix (LF)
line three\r\n // ❌ windows(CRLF)
```