const basicFormatRules = {
    /* ◄◉══▰▰▰  INDENTATION  ▰▰▰══◉► */
    'indent': ['error', 'tab'],                          // ✅ Use tabs (\t) for indentation — never spaces
    'quotes': ['error', 'single'],                       // ✅ Use single quotes: 'hello' (not "hello")
    'semi': ['error', 'always'],                         // ✅ Always end statements with semicolons (disable ASI)
    'brace-style': ['error', '1tbs', {                   // ✅ use "one true brace style"
        allowSingleLine: true                            // ✅ allow single-line blocks:  if (x) { a(); }
    }],
    'max-len': ['error', {
        code: 120,                                       // ✅ Code lines ≤ 120 characters
        comments: 100,                                   // ✅ Comment lines ≤ 100 characters
        ignoreUrls: true,                                // ✅ Allow long URLs
        ignoreStrings: true,                             // ✅ Allow long string literals
        ignoreTemplateLiterals: true,                    // ✅ Allow long template literals(strings with interpolation)
        ignoreRegExpLiterals: true                       // ✅ Allow long RegExp literals
    }],
    
    /* ◄◉══▰▰▰  LINE ENDINGS  ▰▰▰══◉► */
    'eol-last': ['error', 'always'],                     // ✅ Always end file with newline
    'linebreak-style': ['error', 'unix'],                // ✅ \n only        ❌ \r\n
    'no-trailing-spaces': ['error'],                     // ✅ No unnecessary spaces at end-of-line
    'comma-dangle': ['error', 'never'],                  // ✅ No trailing commas in arrays/objects
    'no-multiple-empty-lines': ['error', {
        max: 1,                                          // ✅ There can be only one consecutive blank line
        maxEOF: 1,                                       // ✅ There can be only one blank line at end-of-file   
        maxBOF: 0                                        // ✅ No blank lines at beginning-of-file
    }],

    /* ◄◉══▰▰▰  SPACING RULES  ▰▰▰══◉► */
    'no-mixed-spaces-and-tabs': ['error'],               // ✅ only tabs     ❌ tab + space (no mixing)
    'no-multi-spaces': ['error'],                        // ✅ a = b         ❌ a  =  b
    'space-in-parens': ['error', 'never'],               // ✅ (a + b)       ❌ ( a + b )
    'space-infix-ops': ['error'],                        // ✅ a + b         ❌ a+b
    'array-bracket-spacing': ['error', 'never'],         // ✅ [a, b]        ❌ [ a, b ]
    'space-before-function-paren': ['error', 'never'],   // ✅ fn(a)         ❌ fn (a)
    'no-whitespace-before-property': 'error',            // ✅ obj.a         ❌ obj .a
    'key-spacing': ['error', {                           // ✅ {a: b}        ❌ { a : b }
        beforeColon: false,
        afterColon: true
    }],

    /*  ◄◉══▰▰▰  BLOCKS & BRACES  ▰▰▰══◉► */
    'curly': ['error', 'all'],                           // ✅ Always use curly braces for blocks
    'block-spacing': ['error', 'always'],                // ✅ { a }         ❌ {a}
    'space-before-blocks': ['error', 'always'],          // ✅ if (x) {      ❌ if (x){
    'padded-blocks': ['error', 'never'],                 // ✅ { a; }        ❌ {⏎ a; ⏎}
    'spaced-comment': ['error', 'always', {
        exceptions: ['-', '+']                           // ✅ Allow no space after // or /* if followed by - or +
    }],
    'object-curly-newline': ['error', {                  // ✅ Enforce consistent line breaks inside braces
        ObjectExpression: { multiline: true },
        ObjectPattern: { multiline: true },
        ImportDeclaration: { multiline: true }
    }]    
};
export default basicFormatRules;
